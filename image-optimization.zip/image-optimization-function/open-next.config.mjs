var config = { default: { } };
var open_next_config_default = config;
export { open_next_config_default as default };